class 
b2	
public 
static 
void
main  
23



